package com.cg.ibs.cardmanagement.bean;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="Credit_Card")
public class CreditCardBean {
	
    @Id
    @Column(name = "credit_card_number",length=16)
	private BigInteger creditCardNumber;
	@Column(name = "credit_card_status",nullable = false,length = 7)
	private String creditCardStatus;
	@Column(nullable = false,length = 30,name = "name_on_credit_card")
	private String nameOnCreditCard;
	@Column(nullable = false,length = 3,name="credit_cvv_number")
	private String CreditCvvNum;
	@Column(nullable = false,length = 4,name="cedit_current_pin")
	private String creditCurrentPin;
	@Column(nullable = false,name="credit_date_of_expiry")
	@Temporal(value = TemporalType.DATE)
	private LocalDate creditDateOfExpiry;
	@Column(nullable = false,length = 16,name="UCI")
	private BigInteger UCI;
	@Column(nullable = false,length = 10,name="credit_card_type")
	private String creditCardType;
	@Column(nullable = false ,  length = 3,name="credit_score")
	private int creditScore;
	@Column(nullable = false,name="credit_limit")
	private BigDecimal creditLimit;
	@Column(nullable = false,name="customer_income")
	private double income;
	
	@ManyToOne @JoinColumn
	private CustomerBean custBeanObject;
	
	@OneToMany(mappedBy = "creditBeanObject")
	@JoinColumn
	Set<CreditCardTransaction> creditTransaction=new HashSet<>();
	
	public CreditCardBean() {
		super();
		
	}


	public CreditCardBean(BigInteger creditCardNumber, String creditCardStatus, String nameOnCreditCard,
			String creditCvvNum, String creditCurrentPin, LocalDate creditDateOfExpiry, BigInteger uCI2, String creditCardType,
			int creditScore, BigDecimal creditLimit, double income) {
		super();
		this.creditCardNumber = creditCardNumber;
		this.creditCardStatus = creditCardStatus;
		this.nameOnCreditCard = nameOnCreditCard;
		CreditCvvNum = creditCvvNum;
		this.creditCurrentPin = creditCurrentPin;
		this.creditDateOfExpiry = creditDateOfExpiry;
		this.UCI = uCI2;
		this.creditCardType = creditCardType;
		this.creditScore = creditScore;
		this.creditLimit = creditLimit;
		this.income = income;
	}


	public BigInteger getCreditCardNumber() {
		return creditCardNumber;
	}


	public void setCreditCardNumber(BigInteger creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}


	public String getCreditCardStatus() {
		return creditCardStatus;
	}


	public void setCreditCardStatus(String creditCardStatus) {
		this.creditCardStatus = creditCardStatus;
	}


	public String getNameOnCreditCard() {
		return nameOnCreditCard;
	}


	public void setNameOnCreditCard(String nameOnCreditCard) {
		this.nameOnCreditCard = nameOnCreditCard;
	}


	public String getCreditCvvNum() {
		return CreditCvvNum;
	}


	public void setCreditCvvNum(String creditCvvNum) {
		CreditCvvNum = creditCvvNum;
	}


	public String getCreditCurrentPin() {
		return creditCurrentPin;
	}


	public void setCreditCurrentPin(String creditCurrentPin) {
		this.creditCurrentPin = creditCurrentPin;
	}


	public LocalDate getCreditDateOfExpiry() {
		return creditDateOfExpiry;
	}


	public void setCreditDateOfExpiry(LocalDate creditDateOfExpiry) {
		this.creditDateOfExpiry = creditDateOfExpiry;
	}


	public BigInteger getUCI() {
		return UCI;
	}


	public void setUCI(BigInteger UCI) {
		this.UCI = UCI;
	}


	public String getCreditCardType() {
		return creditCardType;
	}


	public void setCreditCardType(String creditCardType) {
		this.creditCardType = creditCardType;
	}


	public int getCreditScore() {
		return creditScore;
	}


	public void setCreditScore(int creditScore) {
		this.creditScore = creditScore;
	}


	public BigDecimal getCreditLimit() {
		return creditLimit;
	}


	public void setCreditLimit(BigDecimal creditLimit) {
		this.creditLimit = creditLimit;
	}


	public double getIncome() {
		return income;
	}


	public void setIncome(double income) {
		this.income = income;
	}


	@Override
	public String toString() {
		return "CreditCardBean [creditCardNumber=" + creditCardNumber + ", creditCardStatus=" + creditCardStatus
				+ ", nameOnCreditCard=" + nameOnCreditCard + ", CreditCvvNum=" + CreditCvvNum + ", creditCurrentPin="
				+ creditCurrentPin + ", creditDateOfExpiry=" + creditDateOfExpiry + ", UCI=" + UCI + ", creditCardType="
				+ creditCardType + ", creditScore=" + creditScore + ", creditLimit=" + creditLimit + ", income="
				+ income + "]";
	}

}
