package com.cg.ibs.cardmanagement.bean;

import java.math.BigDecimal;
import java.math.BigInteger;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="credit_card_transaction")
public class CreditCardTransaction {
	@Id
	@Column(name = "transation_id")
	private BigInteger transactionid;
	@Column(name="uci",length = 16,nullable = false)
	private BigInteger UCI;
	@Column(name="credit_card_number",length = 16,nullable = false)
	private BigInteger creditCardNumber;
	@Column(name="date_of_trans",nullable = false)
	@Temporal(value = TemporalType.DATE)
	private LocalDateTime dateOfTran;
	@Column(name="amount_of_trans",nullable = false)
	private BigDecimal amount;
	@Column(name="description",nullable = false)
	private String description;
	
	@ManyToOne @JoinColumn
	private CreditCardBean creditBeanObject;
	

	@Override
	public String toString() {
		return "CreditCardTransaction [transactionid=" + transactionid + ", UCI=" + UCI + ", creditCardNumber="
				+ creditCardNumber + ", date=" + dateOfTran + ", amount=" + amount + ", description=" + description + "]";
	}

	public  CreditCardTransaction(BigInteger transactionid, BigInteger uCI, BigInteger creditCardNumber, LocalDateTime date,
			BigDecimal amount, String description) {
		
		this.transactionid = transactionid;
		this.UCI = uCI;
		this.creditCardNumber = creditCardNumber;
		this.dateOfTran = date;
		this.amount = amount;
		this.description = description;
	}
	
	public CreditCardTransaction() {
	super();
	}

	public BigInteger getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(BigInteger transactionid) {
		this.transactionid = transactionid;
	}
	public BigInteger getUCI() {
		return UCI;
	}
	public void setUCI(BigInteger UCI) {
		this.UCI = UCI;
	}
	public BigInteger getCreditCardNumber() {
		return creditCardNumber;
	}
	public void setCreditCardNumber(BigInteger creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	public LocalDateTime getDateOfTran() {
		return dateOfTran;
	}
	public void setDateOfTran(LocalDateTime dateOfTrans) {
		this.dateOfTran = dateOfTrans;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
   
}
