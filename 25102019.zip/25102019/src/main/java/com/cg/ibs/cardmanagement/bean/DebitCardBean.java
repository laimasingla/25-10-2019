package com.cg.ibs.cardmanagement.bean;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

public class DebitCardBean {

	private BigInteger accountNumber;
	private BigInteger debitCardNumber;
	private String debitCardStatus;
	private String nameOnDebitCard;
	private String debitCvvNum;
	private String debitCurrentPin;
	
	@ManyToOne @JoinColumn
	private AccountBean accountBeanObject;

	public BigInteger getUCI() {
		return UCI;
	}

	public void setUCI(BigInteger uCI) {
		this.UCI = uCI;
	}

	private LocalDate debitDateOfExpiry;
	private String debitCardType;
	private BigInteger UCI;
	
	@OneToMany(mappedBy ="debitCardObject") @JoinColumn
	Set<DebitCardTransaction> debitTransaction=new HashSet<>();

	public DebitCardBean() {
		super();

	}

	public DebitCardBean(BigInteger accountNumber, BigInteger debitCardNumber, String debitCardStatus,
			String nameOnDebitCard, String debitCvvNum, String debitCurrentPin, LocalDate debitDateOfExpiry,
			String debitCardType, BigInteger uCI) {
		super();
		this.accountNumber = accountNumber;
		this.debitCardNumber = debitCardNumber;
		this.debitCardStatus = debitCardStatus;
		this.nameOnDebitCard = nameOnDebitCard;
		this.debitCvvNum = debitCvvNum;
		this.debitCurrentPin = debitCurrentPin;
		this.debitDateOfExpiry = debitDateOfExpiry;
		this.debitCardType = debitCardType;
		this.UCI = uCI;
	}

	public BigInteger getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(BigInteger accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigInteger getDebitCardNumber() {
		return debitCardNumber;
	}

	public void setDebitCardNumber(BigInteger debitCardNumber) {
		this.debitCardNumber = debitCardNumber;
	}

	public String getDebitCardStatus() {
		return debitCardStatus;
	}

	public void setDebitCardStatus(String debitCardStatus) {
		this.debitCardStatus = debitCardStatus;
	}

	public String getNameOnDebitCard() {
		return nameOnDebitCard;
	}

	public void setNameOnDebitCard(String nameOnDebitCard) {
		this.nameOnDebitCard = nameOnDebitCard;
	}

	public String getDebitCvvNum() {
		return debitCvvNum;
	}

	public void setDebitCvvNum(String debitCvvNum) {
		this.debitCvvNum = debitCvvNum;
	}

	public String getDebitCurrentPin() {
		return debitCurrentPin;
	}

	public void setDebitCurrentPin(String debitCurrentPin) {
		this.debitCurrentPin = debitCurrentPin;
	}

	public LocalDate getDebitDateOfExpiry() {
		return debitDateOfExpiry;
	}

	public void setDebitDateOfExpiry(LocalDate debitDateOfExpiry) {
		this.debitDateOfExpiry = debitDateOfExpiry;
	}

	public String getDebitCardType() {
		return debitCardType;
	}

	public void setDebitCardType(String debitCardType) {
		this.debitCardType = debitCardType;
	}

	@Override
	public String toString() {
		return "DebitCardBean [accountNumber=" + accountNumber + ", debitCardNumber=" + debitCardNumber
				+ ", debitCardStatus=" + debitCardStatus + ", nameOnDebitCard=" + nameOnDebitCard + ", debitCvvNum="
				+ debitCvvNum + ", debitCurrentPin=" + debitCurrentPin + ", debitDateOfExpiry=" + debitDateOfExpiry
				+ ", debitCardType=" + debitCardType + ", UCI=" + UCI + "]";
	}

}